#include <stdio.h>
#include <time.h>
#include <stdlib.h>
//Here are the special attributes 
  // 0 = armor 1 = health 2 = attack 3 = special attack 
//Global variables
char name[100], *enemyAttack[3];
int clas, enemy[5], elife, move, coins, enemymove, choice, purchase, shop;

//attr structure 
struct attr{
  int armor, shield, attack, special, ammt;//armor
  
  char attackName[100], attackName2[100];

};

//login union
union Login{
  int loginNumber;
  float loginfloat;
  
};

//delay function 
void delay(int number_of_seconds) 
{ 
    // Converting time into milli_seconds 
    int milli_seconds = 1000 * number_of_seconds; 
  
    // Storing start time 
    clock_t start_time = clock(); 
  
    // looping till required time is not achieved 
    while (clock() < start_time + milli_seconds) 
        ; 
} 

//random function for different enemy moves
int randommove() {
  

  srand(time(NULL));

  //random number
  enemymove = rand() % 3;
  
  return enemymove;

}

/*int shop(){
 
  struct attr attr1; 
 
  printf("----------LOUIS' STORE FOR THE WARRIOR----------\n");

  delay(1000);
  printf("Louis: 'what can I get for you today....'");
  delay(1700);
  printf("THE SHOP - \n 5 POINTS ATTACK - 100 COINS \n 5 POINTS SHIELD - 100 COINS \n 5 POINTS SPECIAL ATTACK - 100 COINS \n 1 SPECIAL MOVE - 20 COINS\n HEALTH POTION 25 POINTS - 30\n");

  delay(1700);
  printf("Which one do you want to purchase? 1 - ATTACK 2 - SHIELD 3 - SPECIAL ATTACK 4 - SPECIAL MOVES 5 - HEALTH POTION\n"); 

  scanf("%d", &purchase);

  if (purchase == 1){
    attr1.attack += 5;
    coins -= 10;
    printf("Your attack is now %d", attr1.attack);
    delay(1300);
    printf("Your coins ammount is now %d", coins);
  }

  return coins;
  return attr1.attack;
} 
*/

//battle mechanics
int battle(){
  
  struct attr attr1;
  

  //defining stucture of knight 
  if (choice == 1 ){
        

    attr1.armor = 63; //armor
    attr1.shield = 20; //shield
    attr1.attack = 10;  //attack
    attr1.special = 18; //special attack
    attr1.ammt = 6; //amount of special attacks 
    strcpy(attr1.attackName2, "Broad Slash");
    strcpy(attr1.attackName, "Punch");
  }
  else if (choice == 2 ){
    attr1.armor = 50; //armor
    attr1.shield = 15; //shield
    attr1.attack = 15;  //attack
    attr1.special = 24; //special attack
    attr1.ammt = 3; //amount of special attacks 
    strcpy(attr1.attackName, "Wind Push");
    strcpy(attr1.attackName2, "Fire Ball");

  }
  
  
  
  delay(1000);
  printf("BATTLE BEGINS!!!\n\n");
  while(enemy[0] > 0){
    // The enemy always starts, how can i change it where user starts and the enemy has different choices
    delay(1000);
    printf("It is the enemies move...\n\n");
    
    //random function for different enemy move 
    randommove();

    //enemy does first move 
    if (enemymove == 0){
      attr1.armor -= enemy [2];
      delay(1000);
      printf("The enemy does %s and your health is %d. \n\n", enemyAttack[1], attr1.armor); 
      
    }
    //enemyshields
    else if(enemymove == 1){
      enemy[0] += enemy[1];
      delay(1000);
      printf("The enemy has shielded and their health is %d\n\n", enemy[0]);

    }
    else if(enemymove == 2){
      attr1.armor -= enemy[3];
      delay(1000);
      printf("The enemy does %s and your health is %d\n\n", enemyAttack[2], attr1.armor);
    }


    //Start deat
    if (attr1.armor <= 0){
      delay(1000);
     printf("YOU HAVE BEEN DEFEATED!");
    
     exit(0);
    }

    //your turn
    delay(1000);
    printf("Now its your turn, would you like to use attack, shield, or Special move? \n Choose 1, 2, or 3 \n\n");
    scanf("%d", &move);

    //normal attack 
    if (move == 1){
      enemy[0] -= attr1.attack;
      delay(1000);
      printf("You have decided to attack with %s.\n\n The enemies health is %d\n\n", attr1.attackName ,enemy[0]);
    }
    //shield up
    else if (move == 2){
      attr1.armor += attr1.shield;
      delay(1000);
      printf("You shielded up and your armor is now: %d\n\n", attr1.armor);
    }
    //special move attack
    else if (move == 3){
      if (attr1.ammt == 0){
        delay(1000);
        printf("Sorry you have no more Special moves\n\n"); 
      }
      else {
        attr1.ammt -= 1;
        delay(1000);
        printf("You have %d amount of special moves now\n\n", attr1.ammt);
        enemy[0] -= attr1.special;
        delay(1000);
        printf("You preform %s. \n\n The enemies health is %d\n\n", attr1.attackName2, enemy[0]);
      }
    }

    
    
    
  }

  //if enemy health < 0 
  delay(1000);
  printf("You killed the enemy!\n\n");

  return enemy[0];



}




int main(void) {

  union Login login;

  //login ingo
  
  login.loginNumber = 10;
  login.loginfloat = 53.45;
  //login 
    printf("Hello and welcome to Valhalla... \n\n");\

    delay(1000);

    printf("Your login number is %d\n\n", login.loginNumber);
    delay(1000); 
    printf("The percentage of winning is %f\n\n", login.loginfloat);  
   
   //Character creation
  
  


  delay(1000);
  printf("You wake up in the middle of a grass field cold and scared.\n\n");
  delay(1700);
  printf("A tall sorcerer walks up to you\n\n");
  delay(1500);
  printf("Stranger: 'Hello there I am the Sorcerer of the East!'\n\n");

  //name defining 
  delay(1700);
  printf("Sorcerer of the East: 'What is your name stranger?' ");
  scanf("%s", name);

  delay(1700);
  printf("%s: 'Hello my name is %s'\n\n",name, name);

  delay(1700);
  printf("Sorcerer of the East: 'Welcome %s to the mystical land of Valhalla!'\n\n", name);

  //class creating 

  delay(1800);
  printf("Sorcerer of the East: 'This is a dangerous land with many enemies looking to take your loot!'\n\n");
  delay(1800);
  printf("Sorcerer of the East: 'It is crucial to choose a class and upgrade your abilities to protect yourself.'\n\n");
  delay(1800);
  printf("Sorcerer of the East: 'Number 1. There is the Knight class, coming with a broad sword that can cut an enemy in half.'\n\n");
  delay(1800);
  printf("Sorcer of the East: 'Number 2. There is the Mage class owning a powerful magic staff that controls different elements in Valhalla'\n\n");
  //class chosing
  delay(1800);
  printf("So what class will you choose? Choose 1 or 2\n\n");
  scanf("%d", &clas);

  if (clas == 1)
  {
    //Knight Class
    //attackName[1] = "Punch"; //attack 1 for knight
    //attackName[2] = "Broad Slash"; //special for knight 
    choice = 1;
    delay(1800);
    printf("The Knight has been chosen!\n\n");
    delay(1500);
    printf("The Knight starts of with 63 points of armor and 10 sword points.\n The Knight has 25 points of armor and 18 special ability with 7 uses of this special ability \n\n");
  } 
  else if(clas == 2)
  {
    //Sage class 
     
    choice = 2;
    //attackName[1] = "Wind Push";
    //attackName[2] = "Fire Ball";

    delay(1800);
    printf("The Sage has been chosen!\n\n");
    delay(1500);
    printf("The Sage starts of with 50 armor points and 15 weapon points.\n The Sage also has 15 shield and 24 special move points with 3 special move uses.\n\n");
  }    

  
  

 //Sorcerer leaving
  delay(2250);
  printf("Sorcerer of the East: 'Well chosen %s'.\n\n Sorcerer of the East: 'Hopefully your skills will keep you alive in Valhalla!'\n\n", name);
  delay(2000);
  printf("%s: 'What must I do now Sorcerer?'\n\n", name);
  delay(1300);
  printf("Sorcerer of the East: 'You must defeat the Fafnir! The evil dragon that controls Valhalla!'\n\n");
  delay(1700); 
  printf("Sorcerer of the East: 'I must leave you now. Follow the road to Defeat Fafnir!'\n\n");
  

  delay(1700);
  printf("The Sorcerer fades of into the distance and you begin walking down the road...\n\n");


  //First Enemy Goblin Entrance 
  delay(1000);
  printf("Not long a small Goblin walks towards you.\n\n");

  delay(1500);
  printf("Goblin: 'Hello there, what are you doing on this road all alone...'\n\n");

  delay(1500);
  printf("%s: Be gone I am on an important mission to free Valhalla!'\n\n", name);

  delay(1500);
  printf("You start walking off but the Goblin continues to follow.\n\n");

  delay(1500);
  printf("Goblin: 'Wow going so soon why dont you let me see your weapon?'\n\n");

  delay(1500);
  printf("%s: 'Leave me alone or there will be trouble!' \n\n", name);

  delay(1500);
  printf("The Goblin launches himself at you and...\n\n");
  
  //Goblin stats 
  enemy[0] = 50;//armor
  enemy[1] = 10;//shield
  enemy[2] = 5;//attack
  enemy[3] = 17;//special attack
  enemyAttack[1] = "Dagger Attack";
  enemyAttack[2] = "Dagger Throw";



  battle();
  
  //pick up loot 
  printf("You stand over the Goblin victorious and proud of your victory!\n\n");
  delay(1500);
  printf("There is a pouch hanging on the side of the Goblin,\n you decide to pick it up.\n\n");
  delay(1500);
  printf("Within the pouch is 100 Valhalla coins!\n\n");
  coins += 100;
  printf("Your coin amount is now %d!\n\n", coins);

  /*//store intro 
  delay(1500);
  printf("You look of to the right and see smoke in the air...\n\n");
  
  delay(1500);
  printf("As you walk toward the smoke a small cottage appears\n\n");

  delay(1500);
  printf("On top of the cottage is a sign that reads\n 'LOUIS' STORE FOR THE WARRIOR'\n\n");

  delay(1500);
  printf("You walk in and are greeted by the owner...\n\n");

  delay(1000);
  printf("Louis: 'Hello, your not from around here are you?'\n\n");

  delay(1500);
  printf("%s: 'No, but I am here to free Valhalla and kill the dragon Fafnir!\n\n", name);

  delay(1500);
  printf("Louis lets out a loud laugh\n\n");

  delay(1000);
  printf("Louis: 'Fafnir has not lost a battle in a thoushand years and how do you expect to defeat him.\n\n'");

  delay(1500);
  printf("%s: Are you going to sell me your goods or continue to laugh at me?'\n\n", name);

  delay(1500);
  printf("Louis: 'Well might as well help keep you living as long as I can.'\n\n");

  shop();*/

  //cave battle 
  delay(1500);
  printf("After your glorious battle you continue to walk on the road\n\n");
  delay(1500);
  printf("Clouds begin forming rapidly, and a mighty storm forms...\n\n");
  delay(1500);
  printf("You must look for cover quickly or the storm will over take you!\n\n");
  delay(1500);
  printf("About a hundered feet to your left there is a pitch black cave.\n\n");
  delay(1500);
  printf("You run to the cave to find shelter.\n\n");
  delay(1500);
  printf("Inside the cave it is dark and dusty. So you create a torch to see.\n\n");
  delay(1500);
  printf("You cant tell if your going crazy or not, but there are weird sounds coming from deeper into the cave...\n\n");
  delay(1700);
  printf("%s: 'Hello, is anyone there?'\n\n", name);
  delay(1300);
  printf("A loud growl responds...\n\n ");
  delay(1300);
  printf("Walking into light is a seven foot tall troll.\n\n");
  delay(1300);
  printf("Gagnir: 'WHAT ARE YOU DOING IN MY CAVE!!'\n\n");
  delay(1500);
  printf("%s: 'Im sorry I was only looking for safety during the storm...'\n\n", name);
  delay(1700);
  printf("Gagnir: 'YOU ARE LYING YOU WANT MY TREASURES! THIS MEANS WAR'");
  delay(1500);
  printf("The troll launches a boulder at you and...");
  enemy[0] = 80;//armor
  enemy[1] = 16;//shield
  enemy[2] = 7;//attack
  enemy[3] = 22;//special attack
  enemyAttack[1] = "Troll barf";
  enemyAttack[2] = "Boulder Throw";  
  
  battle();










}