int death(){
  int health, armor, atk;
  
  health = armor - atk;

  if(health <= 0){
    printf("YOU DIED!\n");
    return 0;
  }
  else if (health > 0){
    printf("Your health is %d", health);
  }
  
  return 0;
}

int life(){
  int health; 
  while(health > 0){
    printf("Your health is %d", health);
  }
  return 0;

}
