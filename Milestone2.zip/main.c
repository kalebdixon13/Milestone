#include <stdio.h>
#include <time.h>
#include "delay.h"

// Valhalla
int main() {

  char str[100];
  int clas, armor, weapon, atk, health, desc;
  

  //Character creation
  printf("Hello and welcome to Valhalla...\n\n");

  printf("You wake up in the middle of a grass field cold and scared.\n\n");
  printf("A tall sorcerer walks up to you\n\n");
  printf("Stranger: 'Hello there I am the Sorcerer of the East!'\n\n");

  //name defining 
  printf("Sorcerer of the East: 'What is your name stranger?' ");
  scanf("%s", str);

  printf("You: 'Hello my name is %s'\n\n", str);

  printf("Sorcerer of the East: ' Welcome %s to the mystical land of Valhalla!'\n\n", str);

  //class creating 

  printf("Sorcerer of the East: 'This is a dangerous land with many enemies looking to take your loot!'\n\n");
  printf("Sorcerer of the East: 'It is crucial to chose a class and upgrade your abilities to protect yourself.'\n\n");
  printf("Sorcerer of the East: 'Number 1. There is the Knight class, coming with a broad sword that can cut an enemy in half.'\n\n");
  printf("Sorcer of the East: 'Number 2. There is the Sage class owning a powerful magic staff that controls different elements in Valhalla'\n\n");
  
  //class chosing
  printf("So what will it be? (Choose 1 or 2)\n\n");
  scanf("%d", &clas);

  if (clas == 1)
  {
    //Knight Class
    armor = 5;
    weapon = 5;
    printf("The Knight has been chosen!\n\n The Knight starts of with 5 points of armor and sword.\n\n");
  } 
  else if(clas == 2)
  {
    //Sage class 
    armor = 5;
    weapon = 7;
    printf("The Sage has been chosen!\n\n The Sage starts of with 5 armor points and 7 weapon points.\n\n");
  }
  else
  {
    printf("Sorry incorecct answer.\n");
  }


  //Sorcerer leaving
  printf("Sorcerer of the East: 'Well chosen %s'.\n\n Sorcerer of the East: ' Hopefully your skills will keep you alive in Valhalla!'\n\n", str);
  printf("You: 'What must I do now Sorcerer?'\n\n");
  printf("Sorcerer of the East: 'You must defeat the Fafnir! The evil dragon that controls Valhalla!'\n\n Sorcerer of the East: 'I must leave you now. I wish you well on your Journey!'\n\n");

  //First battle 
  printf("When the Sorcerer leaves a tiny green figure approaches\n\n");
  printf("Green Goblin; 'Hello there, that weapon looks awfuly nice...'\n\n Green Goblin: 'You mind if it I see it?'\n\n");

  printf("Do you give the weapon to the Goblin? [1 for yes, 2 for no]\n\n");
  scanf("%d", &desc);

  if (desc == 1){
    //Goblin attack 
    printf("The Goblin takes the weapon and kills you...\n\n"); 
    atk = 6;
    
    death();
  }
  else if (desc == 2){
    //Goblin Killed
    printf("The Goblin darts at you and you are forced to kill him\n\n");
    printf("The Goblin does 2 damage\n\n");
    
    atk = 2;
    armor -= atk; 
    printf("Your armor is %d\n\n", armor);

    printf("There is a potion on the ground. On the front it says FOR KNIGHTS ONLY. You decide to pick it up to take it\n\n");
    for (int armor = 3; armor <= 5; armor = armor + 1 ){
      printf("Your armor is %d\n\n", armor);
    }
    


  }
 
  
  

  
  

  
  

 
}

